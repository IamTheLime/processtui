# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['processtui']

package_data = \
{'': ['*']}

install_requires = \
['asyncio>=3.4.3,<4.0.0',
 'pydantic>=1.10.2,<2.0.0',
 'textual[dev]>=0.4.0,<0.5.0']

setup_kwargs = {
    'name': 'processtui',
    'version': '0.1.0',
    'description': '',
    'long_description': '',
    'author': 'Tiago Lime, The Lime',
    'author_email': 'tiago@myurbanjungle.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
